# Hot Gadgets

[Website](https://sifatmoonjerin.github.io/hot-gadgets/)

A dummy online gadget store.

### Technology
- HTML5
- CSS3
- Bootstrap

